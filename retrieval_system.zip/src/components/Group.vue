<template>
    <div>
        <h2>组群管理功能页面</h2>
    </div>
</template>