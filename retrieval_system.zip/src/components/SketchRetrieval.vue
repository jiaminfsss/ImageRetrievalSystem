<template>
    <div>
        <h2>草图搜图功能页面</h2>
    </div>
</template>