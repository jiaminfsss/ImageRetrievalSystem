<template>
    <div class="title">
        <!-- <h1 style="text-align:center;">以图搜图功能页面</h1> -->
        <h1>以图搜图功能页面</h1>
    </div>
</template>


<script>

</script>

<style lang="less" scoped>
h1 {
    text-align: center;
    font-size: 40px;
}
</style>