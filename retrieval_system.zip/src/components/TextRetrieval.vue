<template>
    <div>
        <h2>文字搜图功能页面</h2>
    </div>
</template>