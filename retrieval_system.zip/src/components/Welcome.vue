<template>
    <div>
        <h2>欢迎页面</h2>
    </div>
</template>