<template>
    <div>
        <h1>图像管理功能页面</h1>
    </div>
</template>